package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import com.example.myapplication.activities.Calculator;
import com.example.myapplication.activities.Color_change;
import com.example.myapplication.activities.Contact_us;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_main);

        Button Btn_calcultor =findViewById(R.id.button_first_link);
        Btn_calcultor.setOnClickListener((v)->{
            Intent intent = new Intent(this,Calculator.class);
            startActivity(intent);
        });

        Button Btn_color_change = findViewById(R.id.button_second_link);
        Btn_color_change.setOnClickListener((v)->{
            Intent intent = new Intent(this, Color_change.class);
            startActivity(intent);
        });

        Button Btn_contact_us = findViewById(R.id.button_third_link);
        Btn_contact_us.setOnClickListener((v)->{
            Intent intent2 = new Intent(this, Contact_us.class);
            startActivity(intent2);
        });
    }
}