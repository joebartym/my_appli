package com.example.myapplication.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import com.example.myapplication.R;
import com.google.android.material.snackbar.Snackbar;

public class Contact_us extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_contact_us);
        Button btnEmail = findViewById(R.id.btnEmail);
        btnEmail.setOnClickListener((v) -> {
            Intent intent = new Intent(Intent.ACTION_SENDTO);
            intent.putExtra(Intent.EXTRA_EMAIL, "sven.clement@univ-perp.fr");
            intent.putExtra(Intent.EXTRA_SUBJECT, "Hello");
            if (intent.resolveActivity(getPackageManager()) == null) {
                Snackbar.make(findViewById(android.R.id.content), "No Activity found to handle Intent", Snackbar.LENGTH_LONG).show();
            } else {
                startActivity(intent);
            }
        });
    }

}