package com.example.myapplication.models;

import static java.lang.Integer.MAX_VALUE;
import static java.lang.Integer.MIN_VALUE;

public class Calculi {

    private int stack = 0;
    private int stack_add_one = 0;
    private char sign = ' ';
    public Calculi(){

        reset();}
    public void get_result(){
        this.do_calc(); stack_add_one =  stack;sign = ' ';}

    public int get_op(){return stack_add_one;}
    public char get_Sign(){return sign;}
    public void set_sign(char sig){sign = sig;}

    public void do_calc(){
        if(sign == '+')
            stack += stack_add_one;
        else if(sign == '-')
            stack -= stack_add_one;
        else if(sign == 'x')
            stack *= stack_add_one;
        else if(sign == '/' && stack_add_one != 0)
            stack /= stack_add_one;
    }

    public void cut_nbr(){stack_add_one /= 10;}
    public void ANS(){ stack_add_one = stack;}
    public void Opp(){stack_add_one *= -1;}
    public void reset(){stack_add_one = 0; stack = 0;sign = ' ';}

    public void put_on_sign(char sig){
        if(stack_add_one == 0) //
            this.set_sign(sig);
        else
        {

            if(stack == 0 || sign == ' ')
                stack = stack_add_one;
            else
                this.do_calc();
            this.set_sign(sig);
            stack_add_one = 0;
        }


    }

    public void put_on_number(int nbr)
    {
        if(stack_add_one<MAX_VALUE/10 && stack_add_one>MIN_VALUE/10) //
            if(stack_add_one>=0)
                stack_add_one = stack_add_one*10 + nbr;
            else
                stack_add_one = stack_add_one*10 - nbr;
    }
}
