package com.example.myapplication.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import com.example.myapplication.R;
import com.example.myapplication.models.Calculi;

public class Calculator extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_calculator);

        Calculi Cal_Hard = new Calculi(); //the main of this part

        Button btn_ch0 = findViewById(R.id.chiffre_0);btn_ch0.setOnClickListener((v) ->put_nbm(0,Cal_Hard)); // just add the number on the stack
        Button btn_ch1 = findViewById(R.id.chiffre_1);btn_ch1.setOnClickListener((v) ->put_nbm(1,Cal_Hard));
        Button btn_ch2 = findViewById(R.id.chiffre_2);btn_ch2.setOnClickListener((v) ->put_nbm(2,Cal_Hard));
        Button btn_ch3 = findViewById(R.id.chiffre_3);btn_ch3.setOnClickListener((v) ->put_nbm(3,Cal_Hard));
        Button btn_ch4 = findViewById(R.id.chiffre_4);btn_ch4.setOnClickListener((v) ->put_nbm(4,Cal_Hard));
        Button btn_ch5 = findViewById(R.id.chiffre_5);btn_ch5.setOnClickListener((v) ->put_nbm(5,Cal_Hard));
        Button btn_ch6 = findViewById(R.id.chiffre_6);btn_ch6.setOnClickListener((v) ->put_nbm(6,Cal_Hard));
        Button btn_ch7 = findViewById(R.id.chiffre_7);btn_ch7.setOnClickListener((v) ->put_nbm(7,Cal_Hard));
        Button btn_ch8 = findViewById(R.id.chiffre_8);btn_ch8.setOnClickListener((v) ->put_nbm(8,Cal_Hard));
        Button btn_ch9 = findViewById(R.id.chiffre_9);btn_ch9.setOnClickListener((v) ->put_nbm(9,Cal_Hard));

        Button btn_smb_add = findViewById(R.id.symbol_add); btn_smb_add.setOnClickListener((v) -> put_symbol('+',Cal_Hard));
        Button btn_smb_sub = findViewById(R.id.symbol_sous);btn_smb_sub.setOnClickListener((v) -> put_symbol('-',Cal_Hard));
        Button btn_smb_mul = findViewById(R.id.symbol_mul);btn_smb_mul.setOnClickListener((v) -> put_symbol('x',Cal_Hard));
        Button btn_smb_div = findViewById(R.id.symbol_div);btn_smb_div.setOnClickListener((v) -> put_symbol('/',Cal_Hard));
        Button btn_smb_equ = findViewById(R.id.symbol_equal);btn_smb_equ.setOnClickListener((v) -> put_option("equ",Cal_Hard));
        Button btn_smb_eff = findViewById(R.id.symbol_efface);btn_smb_eff.setOnClickListener((v) -> put_option("eff",Cal_Hard));
        Button btn_smb_res = findViewById(R.id.symbol_reset);btn_smb_res.setOnClickListener((v) -> put_option("res",Cal_Hard));
        Button btn_smb_ANS = findViewById(R.id.symbol_ANS);btn_smb_ANS.setOnClickListener((v) -> put_option("ANS",Cal_Hard));
        Button btn_smb_opp = findViewById(R.id.symbol_opp);btn_smb_opp.setOnClickListener((v) -> put_option("opp",Cal_Hard));

        Button button_return = findViewById(R.id.bouton_retours_calc); button_return.setOnClickListener((v)->{this.finish();});
    }


    private void update_Display(Calculi Cal_Hard){
        TextView stack_add_on =findViewById(R.id.output_result_calculator);
        TextView sign =findViewById(R.id.output_sign_calculator);

        stack_add_on.setText(String.valueOf(Cal_Hard.get_op()));
        sign.setText(String.valueOf(Cal_Hard.get_Sign()));
    }
    private void put_nbm(int nbr, Calculi Cal_Hard){
        Cal_Hard.put_on_number(nbr);
        update_Display(Cal_Hard);
    }
    private void put_symbol(char smb,Calculi Cal_Hard) {
        Cal_Hard.put_on_sign(smb);
        update_Display(Cal_Hard);
    }
    private void put_option(String smb,Calculi Cal_hard){
        if(smb.equals("equ"))
            Cal_hard.get_result();
        else if(smb.equals("eff"))
            Cal_hard.cut_nbr();
        else if(smb.equals("res"))
            Cal_hard.reset();
        else if(smb.equals("ANS"))
            Cal_hard.ANS();
        else if(smb.equals("opp"))
            Cal_hard.Opp();
        update_Display(Cal_hard);
    }
}